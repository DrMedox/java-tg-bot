package com.urfu.tg_bot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TgBotApplicationTests {

	@Test
	void contextLoads() {
	}

}
